package com.JPA.EmployeeJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
